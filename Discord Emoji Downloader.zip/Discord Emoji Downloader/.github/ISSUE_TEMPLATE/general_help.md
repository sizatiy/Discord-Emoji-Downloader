<!-- Thank you for the issue! Please provide details: -->

## Summary
<!-- One line summary -->

## Platform
- [ ] Windows (.EXE)
- [ ] Windows (Python)
- [ ] Other

## Details
<!-- Additional context -->
