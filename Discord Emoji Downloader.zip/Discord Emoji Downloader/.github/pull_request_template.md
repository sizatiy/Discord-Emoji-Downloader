<!-- Thank you for using Discord Emoji Downloader! Before submitting, please check: -->

- [ ] I have read the README
- [ ] I have checked existing issues
- [ ] This is not a security vulnerability

## Description
<!-- Clear description of your changes -->

## Related Issue
<!-- Link to issue: fixes #123 -->

## Testing
<!-- How should this be tested? -->

## Checklist
- [ ] My code follows the project style
- [ ] I have tested this change
- [ ] This works on Windows
